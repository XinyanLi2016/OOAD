package ant;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PlayRoom extends JFrame implements ActionListener {
	
	Container c;
	
	// 面板1：初始值设定
	JPanel p1;
	JLabel antId[];
	JComboBox initialDirection[];
	
	// 面板2：按钮
	JPanel p2;
	JButton start,startMin,startMax,end;
	
	// 游戏运动
	CreepingGame creepingGame;
	
	// 最小最大时间
	boolean maxAnt[],minAnt[];
	int maxTime,minTime;

	public PlayRoom() throws HeadlessException {
		super("蚂蚁爬杆");
		c = getContentPane();
		c.setLayout(new GridLayout(3,1,10,10));
		initPanel1();
		initPanel2();
		c.add(p1);
		c.add(p2);
		creepingGame = new CreepingGame();
		c.add(creepingGame);
		
		maxAnt = new boolean[5];
		minAnt = new boolean[5];
		maxTime = 0;
		minTime = 0;
		
		getMinAndMax();
	}

	private void initPanel1() {
		p1 = new JPanel();
		p1.setLayout(new GridLayout(1,10,70,0));
		antId = new JLabel[5];
		initialDirection = new JComboBox[5];
		String str[] = {"左","右"};
		for(int i = 0; i < 5; i++) {
			antId[i] = new JLabel("蚂蚁" + (i+1) + "号");
			initialDirection[i] = new JComboBox(str);
			p1.add(antId[i]);
			p1.add(initialDirection[i]);
		}
	}
	
	private void initPanel2() {
		p2 = new JPanel();
		p2.setLayout(new GridLayout(1,4,50,0));
		
		start = new JButton("开  始");
		startMin = new JButton("最短时间情况开始");
		startMax = new JButton("最长时间情况开始");
		end = new JButton("结  束");
		
		start.addActionListener(this);
		startMin.addActionListener(this);
		startMax.addActionListener(this);
		end.addActionListener(this);
		
		end.setEnabled(false);
		
		p2.add(start); 
		p2.add(startMin);
		p2.add(startMax);
		p2.add(end);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlayRoom playRoom = new PlayRoom();
		playRoom.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();             //获取屏幕的尺寸
	    int screenWidth = screenSize.width;                     //获取屏幕的宽
	    int screenHeight = screenSize.height;                   //获取屏幕的高
	    int windowWidth = 1500;
	    int windowHeight = 200;
	    playRoom.setBounds(screenWidth/2-windowWidth/2, screenHeight/2-windowHeight/2,windowWidth,windowHeight);
		playRoom.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == end) {
			creepingGame.endGame();
			end.setEnabled(false);
			start.setEnabled(true);
			startMin.setEnabled(true);
			startMax.setEnabled(true);
			
			startMin.setText("最短时间情况开始");
			startMax.setText("最长时间情况开始");
		}
		else {
			Ant[] ant = new Ant[5];
			int location[] = {30,80,110,160,250};
			int velocity = 5;
			if(e.getSource() == start) {
				for(int i = 0; i < 5; i++) {
					boolean direction = true;
					if(initialDirection[i].getSelectedItem() == "左")
						direction = false;
					ant[i] = new Ant(location[i],direction,velocity);
				}
			}
			
			else if(e.getSource() == startMin) {
				
				startMin.setText("最短时间为：" + minTime);
				
				for(int i = 0; i < 5; i++) {
					if(minAnt[i] == false)
						initialDirection[i].setSelectedItem("左");
					else
						initialDirection[i].setSelectedItem("右");
				}
				
				for(int i = 0; i < 5; i++) {
					ant[i] = new Ant(location[i],minAnt[i],velocity);
				}
			}
			
			else if(e.getSource() == startMax) {
				
				startMax.setText("最长时间为：" + maxTime);
				
				for(int i = 0; i < 5; i++) {
					if(maxAnt[i] == false)
						initialDirection[i].setSelectedItem("左");
					else
						initialDirection[i].setSelectedItem("右");
				}
				
				for(int i = 0; i < 5; i++) {
					ant[i] = new Ant(location[i],maxAnt[i],velocity);
				}
			}
			
			start.setEnabled(false);
			startMin.setEnabled(false);
			startMax.setEnabled(false);
			end.setEnabled(true);
			
			int poleLength = 300;
			creepingGame.setData(ant, poleLength);
			creepingGame.playGame();
		}
		
	}
	
	/**
	 * 	获取所有情况中的最小时间和最大时间及其分别对应的初始值
	 */
	private void getMinAndMax() {
		int poleLength = 300;
		int location[] = {30,80,110,160,250};
		int velocity = 5;
		boolean currentAnt[] = new boolean[5];
		int currentTime = 0;
		boolean direction[] = {false,true};
		for(int i0 = 0; i0 < 2; i0++) {
			currentAnt[0] = direction[i0];
			for(int i1 = 0; i1 < 2; i1++) {
				currentAnt[1] = direction[i1];
				for(int i2 = 0; i2 < 2; i2++) {
					currentAnt[2] = direction[i2];
					for(int i3 = 0; i3 < 2; i3++) {
						currentAnt[3] = direction[i3];
						for(int i4 = 0; i4 < 2; i4++) {
							currentAnt[4] = direction[i4];
							
							
							Ant ant[] = new Ant[5];
							
							for(int i = 0; i < 5; i++)
								ant[i] = new Ant(location[i],currentAnt[i],velocity);
							
							for(int j = 0; j < 5; j++) {
								System.out.print(currentAnt[j] + " ");
							}
							System.out.println();
							
							creepingGame.setData(ant, poleLength);
							currentTime = creepingGame.CalTime();
							
							if(maxTime == 0 && minTime == 0) {
								maxTime = minTime = currentTime;
								for(int i = 0; i < 5; i++) {
									maxAnt[i] = currentAnt[i];
									minAnt[i] = currentAnt[i];
								}
							}
								
							else if(maxTime < currentTime) {
								maxTime = currentTime;
								for(int i = 0; i < 5; i++) {
									maxAnt[i] = currentAnt[i];
								}
							}
							
							else if(minTime > currentTime) {
								minTime = currentTime;
								for(int i = 0; i < 5; i++) {
									minAnt[i] = currentAnt[i];
								}
							}
						}
					}
				}
			}
		}
		
	}

}
