package ant;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class CreepingGame extends JPanel {
	private Ant initialAnt[];
	private Pole pole;
	private int time;

	private List<Ant> ant;
	
	private boolean start;

	public CreepingGame() {
		super();
		time = 0;
		ant = new ArrayList<Ant>();
		
		start = false;
	}

	public void setData(Ant[] initialAnt, int poleLength) {
		this.initialAnt = initialAnt;
		pole = new Pole(0, poleLength);
		for (int i = 0; i < initialAnt.length; i++)
			ant.add(initialAnt[i]);
	}
	
	/**
	 * 游戏一步一步推进
	 */
	private void drivingGame() {
		// 蚂蚁爬行并检测是否爬出去
		for (int i = 0; i < ant.size(); i++) {
			Ant current = ant.get(i);

			// 蚂蚁爬行
			current.creeping();

			int location = current.getLocation();
			if (location < pole.getLeftLocation() || location > pole.getRightLocation()) {// 蚂蚁爬出去了
				ant.remove(i); // 把该蚂蚁从链表中移除
				i--;
			}
		}
		
		// 时间推进
		if(!ant.isEmpty())
			time++;

		// 判断蚂蚁是否碰头
		for (int i = 0; i < ant.size() - 1; i++) {
			if (meet(ant.get(i), ant.get(i + 1))) { // 蚂蚁碰头
				ant.get(i).changeDiretion();
				ant.get(i + 1).changeDiretion();
			}

		}
		
		
	}
	
	/**
	 * 	检测是否碰面
	 * @param antLeft 左蚂蚁
	 * @param antRight	右蚂蚁
	 * @return true代表碰面
	 */
	private boolean meet(Ant antLeft, Ant antRight) {
		return antLeft.getLocation() == antRight.getLocation();
	}
	
	/**
	 * 开始游戏
	 */
	public void playGame() {
		start = true;
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				time = 0;
				while (start && !ant.isEmpty()) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					drivingGame();
				}
			}
		}).start();

	}
	
	/**
	 *   	结束游戏
	 */
	public void endGame() {
		time = 0;
		ant = new ArrayList<Ant>();
		
		start = false;
	}


	@Override
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		g.setColor(Color.black);
		g.drawString("时间："+ time, 1400, 20);
		for(int i = 0; i < 60; i++) {
			g.setColor(Color.red);			
			g.drawString(""+i*5, i*22+50, 20);
			g.draw3DRect(50+i*22, 20, 22, 22,false);
			
			for(int j = 0; j < ant.size(); j++) {
				if(ant.get(j).getLocation() == i*5) {
					g.setColor(Color.blue);
					g.fill3DRect(50+i*22, 20, 22, 22,false);
				}
			}
		}
		
		repaint();
	}
	
	/**
	 * 	计算时间
	 * @return 返回值表示每种情况所用的时间
	 */
	public int CalTime() {
		time = 0;
		while (!ant.isEmpty()) {
			drivingGame();
		}
		return time;
	}

}
