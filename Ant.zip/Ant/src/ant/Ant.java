package ant;

public class Ant {
	private int location;
	private boolean direction;
	private int velocity;

	public Ant(int location, boolean direction, int velocity) {
		super();
		this.location = location;
		this.direction = direction;
		this.velocity = velocity;
	}

	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	public boolean isDirection() {
		return direction;
	}

	public void setDirection(boolean direction) {
		this.direction = direction;
	}

	public int getVelocity() {
		return velocity;
	}

	public void setVelocity(int velocity) {
		this.velocity = velocity;
	}
	
	public void changeDiretion() {
		direction = !direction;
	}
	
	public void creeping() {
		if(direction)
			location += velocity;
		else
			location -= velocity;
	}
}
