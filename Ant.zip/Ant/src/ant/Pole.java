package ant;

public class Pole {
	private int leftLocation;
	private int rightLocation;

	public Pole(int leftLocation, int rightLocation) {
		super();
		this.leftLocation = leftLocation;
		this.rightLocation = rightLocation;
	}

	public int getLeftLocation() {
		return leftLocation;
	}

	public void setLeftLocation(int leftLocation) {
		this.leftLocation = leftLocation;
	}

	public int getRightLocation() {
		return rightLocation;
	}

	public void setRightLocation(int rightLocation) {
		this.rightLocation = rightLocation;
	}
}
